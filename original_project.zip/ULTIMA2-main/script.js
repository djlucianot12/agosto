document.addEventListener('DOMContentLoaded', () => {
    // Add any JavaScript functionality here.
    // For now, we'll just log a message to the console.
    console.log('as mobius clone loaded.');
});
